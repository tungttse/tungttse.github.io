import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;

public class SupportServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        PrintWriter writer = resp.getWriter();

        writer.append("<!DOCTYPE html>\r\n");
        writer.append("<html><title>Demo Servlet</title>");
        writer.append("<body>");
        writer.append("<form action=\"/support\" method=\"POST\">");
        writer.append("Name <input type=\"text\" name=\"name\" required/></br>");
        writer.append("Email <input type=\"email\" name=\"email\" required/></br>");
        writer.append("Problem <input type=\"text\" name=\"problem\" required/></br>");
        writer.append("Problem description<textarea name=\"problem_description\" required cols='30' rows='5'></textarea></br>");
        writer.append("<input type=\"submit\" value=\"help\" />");
        writer.append("</form>");
        writer.append("</body>");
        writer.append("</html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String emailSupport = getServletContext().getInitParameter("email_support");
        String ticketId = UUID.randomUUID().toString();

        PrintWriter writer = resp.getWriter();
        writer.append("Thank you! "+ name +" for contacting us. </br>" +
                " We should receive reply from us with in 24 hrs </br>" +
                "in your email address "+ email +". Let us know in our support email "+ emailSupport +"</br>" +
                "if you don’t receive reply within 24 hrs. Please be sure to attach your reference " + ticketId +" in your email");
    }
}
