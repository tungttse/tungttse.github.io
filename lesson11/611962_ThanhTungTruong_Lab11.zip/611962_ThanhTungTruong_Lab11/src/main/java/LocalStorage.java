import models.User;

public class LocalStorage {
    public static User getUserInfoByeUsername(String username) {
        return new User(username);
    }
}
