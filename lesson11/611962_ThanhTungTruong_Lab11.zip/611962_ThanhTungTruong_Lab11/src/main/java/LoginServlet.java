import models.User;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        PrintWriter writer = resp.getWriter();

        HttpSession session = req.getSession();
        if (session.getAttribute("username") != null) {
            String username = session.getAttribute("username").toString();
            writer.append("Welcome " + username + " come back!");
            writer.append("<form action=\"logout\" method=\"POST\">");
            writer.append("<input type=\"hidden\" name=\"action\" value=\"logout\"/></br>");
            writer.append("<input type=\"submit\" value=\"Logout\" />");
            writer.append("</form>");
        } else {
            Cookie[] cookies = req.getCookies();
            writer.append("<form action=\"login\" method=\"POST\">");
            writer.append("<input type=\"hidden\" name=\"action\" value=\"login\"/></br>");
            writer.append("Username <input type=\"text\" name=\"username\"/></br>");
            writer.append("Password <input type=\"password\" name=\"password\" /></br>");

            String isRemember = "off";
            for (Cookie aCookie : cookies) {
                if (aCookie.getName().equals("remember_me")) {
                    isRemember = aCookie.getValue();
                }
            }

            if (isRemember.equals("on")) {
                writer.append("Remember Me <input type=\"checkbox\" name=\"remember_me\" checked /></br>");
            } else {
                writer.append("Remember Me <input type=\"checkbox\" name=\"remember_me\" /></br>");
            }
            writer.append("<input type=\"submit\" value=\"Login\" />");
            writer.append("</form>");
        }

        writer.append("<a href=\"/welcome\">Go to Private Space - Loged In only</a>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userName = req.getParameter("username");
        String password = req.getParameter("password");
        String action = req.getParameter("action");
        String rememberMe = req.getParameter("remember_me");

        if (action.equals("login")) {
            if ("admin".equals(userName) && "123123".equals(password)) {
                User currenUser = LocalStorage.getUserInfoByeUsername(userName);
                HttpSession session = req.getSession();
                session.setMaxInactiveInterval(30 * 60);
                session.setAttribute("username", currenUser.getUsername());

                //handle cookie
                Cookie cookiePromo = new Cookie("promo", "$100");
                cookiePromo.setMaxAge(30 * 24 * 60 * 60);

                Cookie cookieUsername = new Cookie("username", "");
                cookieUsername.setMaxAge(0);
                Cookie cookieRememberme = new Cookie("remember_me", "");
                cookieRememberme.setMaxAge(0);

                if (rememberMe != null && rememberMe.equals("on")) {
                    cookieUsername.setValue(currenUser.getUsername());
                    cookieUsername.setMaxAge(30 * 24 * 60 * 60); // 30 days
                    cookieRememberme.setValue("on");
                    cookieRememberme.setMaxAge(30 * 24 * 60 * 60); // 30 days
                }
                resp.addCookie(cookieUsername);
                resp.addCookie(cookieRememberme);
            }
        } else { // logout action
            HttpSession session = req.getSession(false);
            session.removeAttribute("username");
            session.getMaxInactiveInterval();
        }
        resp.sendRedirect("/login");
    }
}
