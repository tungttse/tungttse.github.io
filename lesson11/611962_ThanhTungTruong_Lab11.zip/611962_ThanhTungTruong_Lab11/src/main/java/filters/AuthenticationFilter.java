package filters;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class AuthenticationFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        HttpSession session = request.getSession();
        if ( session.getAttribute("username") != null ) {
            filterChain.doFilter(req, resp);//sends request to next resource
        } else {
            response.sendRedirect("/login");
        }

        //        String userName = req.getParameter("username");
//        String password = req.getParameter("password");
//        String action = req.getParameter("action");
//
//        if (action.equals("login")) {
//            if ("admin".equals(userName) && "123123".equals(password)) {
//                filterChain.doFilter(req, resp);//sends request to next resource
//            } else {
//                RequestDispatcher rd = req.getRequestDispatcher("login");
//                rd.include(req, resp);
//            }
//        }
    }

    @Override
    public void destroy() {

    }
}
