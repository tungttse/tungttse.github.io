package io.github.akkhadka.webstore.controller.admin.exception;

public class ApiException extends Exception{

    public ApiException(String err){
        super(err);
    }
}
