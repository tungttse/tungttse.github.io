package io.github.akkhadka.webstore.model;

public interface CartService {
}
