package io.github.akkhadka.webstore.controller.viewmodels.Json;

public class JSONResult {
    private String result;
    private String value;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
