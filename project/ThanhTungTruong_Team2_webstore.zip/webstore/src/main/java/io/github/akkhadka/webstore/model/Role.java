package io.github.akkhadka.webstore.model;

public enum Role {
    CUSTOMER,
    ADMIN
}
